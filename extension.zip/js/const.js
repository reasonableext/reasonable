(function() {
  window.GET_URL = "http://www.brymck.com/reasonable/get";
  window.GIVE_URL = "http://www.brymck.com/reasonable/give";
  window.QUICKLOAD_MAX_ITEMS = 20;
  window.actions = {
    black: {
      label: "hide",
      value: "black"
    },
    white: {
      label: "show",
      value: "white"
    },
    auto: {
      label: "auto",
      value: "auto"
    }
  };
}).call(this);
